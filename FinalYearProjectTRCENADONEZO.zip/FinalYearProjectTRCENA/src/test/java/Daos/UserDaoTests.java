/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Daos;

import Daos.UserDao;
import Dtos.User;
import static java.sql.Types.NULL;
import java.util.ArrayList;
import java.util.List;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.BeforeClass;

/**
 *
 * @author ruzinskastomas
 */
public class UserDaoTests {
    
    public UserDaoTests() {
    }

    @BeforeClass
    public static void setUpClass()
    {
        UserDao UserDao = new UserDao("fishmoley");
    }

    /**
     * Test of getUserLoans method, of class LoanDao.
     * Check that the number of entries retrieved matches the (known) size of the test database's table
     * Only returns unpaid loans.
     */

    @Test
    public void Login()
    {   String username = "tomas";
        String password = "a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3";
         UserDao instance = new UserDao("fishmoley");
        int expResult = 2;
        int result = instance.Login(username, password);
        assertEquals(expResult, result);
        
    }

}

