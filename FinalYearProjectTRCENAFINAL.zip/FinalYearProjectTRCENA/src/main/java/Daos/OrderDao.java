/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Daos;

import Dtos.Order;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author ruzinskastomas
 */
public class OrderDao extends Dao{
    public OrderDao(String databaseName) {
        super(databaseName);
    }
     public int addProductToBasket(int product_id,int quantity, int userid) {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int added = 0;
        int rowsAffected = 0;

        try {

            con = this.getConnection();

            String query = ("INSERT INTO user_order_products(product_id,quantity,user_id) VALUES (?,?,?)");

            ps = con.prepareStatement(query);
            ps.setInt(1, product_id);
            ps.setInt(2, quantity);
            ps.setInt(3, userid);
            rowsAffected = ps.executeUpdate();

            if (rowsAffected > 0) {
                added = 1;
            } else {
                added = 0;
            }

        } catch (SQLException se) {
            System.out.println("SQL Exception occurred: " + se.getMessage());
            se.printStackTrace();
        } catch (Exception e) {
            System.out.println("Exception occurred: " + e.getMessage());
            e.printStackTrace();
        } finally {
            // Close the result set, statement and the connection
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException ex) {
                    System.out.println("Exception occurred when attempting to close ResultSet: " + ex.getMessage());
                }
            }
            if (ps != null) {
                try {
                    ps.close();
                } catch (SQLException ex) {
                    System.out.println("Exception occurred when attempting to close the PreparedStatement: " + ex.getMessage());
                }
            }
            if (con != null) {
                try {
                    con.close();
                } catch (SQLException ex) {
                    System.out.println("Exception occurred when attempting to close the Connection: " + ex.getMessage());
                }
            }
        }
        return added;
    }
     public ArrayList<Order> AllOrdersByUserId(String user_id) {
        ArrayList<Order> orders = new ArrayList();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = getConnection();

            String query = "SELECT * FROM user_order_products where active = 1 && user_id = ?";
            ps = conn.prepareStatement(query);
            ps.setString(1, user_id);
            rs = ps.executeQuery();

            while (rs.next()) {
                Order o = new Order();

                o.setOrder_id(rs.getString("order_id"));
                o.setUser_id(rs.getString("user_id"));
                o.setProduct_id(rs.getString("product_id"));
                o.setQuantity(rs.getInt("quantity"));

                orders.add(o);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
            } catch (SQLException e) {
                System.out.println("An exception occurred when closing the ResultSet of the getAllProducts(): " + e.getMessage());
            }
            try {
                if (ps != null) {
                    ps.close();
                }
            } catch (SQLException e) {
                System.out.println("An exception occurred when closing the PreparedStatement of the getAllProducts(): " + e.getMessage());
            }
            freeConnection(conn);
        }
        return orders;
    }
     public ArrayList<Order> AllOrdersHistoryByUserId(String user_id) {
        ArrayList<Order> orders = new ArrayList();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = getConnection();

            String query = "SELECT * FROM user_order_products where active = 0 && user_id = ?";
            ps = conn.prepareStatement(query);
            ps.setString(1, user_id);
            rs = ps.executeQuery();

            while (rs.next()) {
                Order o = new Order();

                o.setOrder_id(rs.getString("order_id"));
                o.setUser_id(rs.getString("user_id"));
                o.setProduct_id(rs.getString("product_id"));
                o.setQuantity(rs.getInt("quantity"));

                orders.add(o);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
            } catch (SQLException e) {
                System.out.println("An exception occurred when closing the ResultSet of the getAllProducts(): " + e.getMessage());
            }
            try {
                if (ps != null) {
                    ps.close();
                }
            } catch (SQLException e) {
                System.out.println("An exception occurred when closing the PreparedStatement of the getAllProducts(): " + e.getMessage());
            }
            freeConnection(conn);
        }
        return orders;
    }
}
