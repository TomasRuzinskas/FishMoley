/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Commands;

import Daos.ProductDao;
import Dtos.Product;
import java.util.ArrayList;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Colm
 */
public class DeleteCommand implements Command {

    public String execute(HttpServletRequest request, HttpServletResponse response) {
        String forwardToJsp = "";

        String product_idString = request.getParameter("product_id");

        if (product_idString != null) {
            try {
                int product_id = Integer.parseInt(product_idString);


                ProductDao productdao = new ProductDao("fishmoley");

                int results = productdao.Delete(product_id);

                HttpSession session = request.getSession();

                session.setAttribute("numUpdated", results);

                if (results > 0) {
         //           ArrayList<Product> products = productdao.getProductsByName(product_name);
                    session.setAttribute("deletedProducts", "deleted product");
                  forwardToJsp = "deleteProducts.jsp";                       
                }
                
                else   {
                  //  request.getSession();

                  //  session.setAttribute("deletedProducts", "failed to delete product");
                    forwardToJsp = "failedDeletedProduct.jsp";
                }
               
            } catch (NumberFormatException e) {
                forwardToJsp = "error.jsp";
                HttpSession session = request.getSession();

                // session.setAttribute("errorMessage", "Text was supplied for the amount to be updated by.");
            }
        } else {

            forwardToJsp = "error.jsp";

            HttpSession session = request.getSession();

            session.setAttribute("errorMessage", "A parameter value required for deleting was missing");
        }
        return forwardToJsp;
    }

}
