/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Commands;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import Daos.OrderDao;
import Daos.UserDao;
import Dtos.User;
/**
 *
 * @author ruzinskastomas
 */
public class AddToCartCommand implements Command{
    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response) {
        String forwardToJsp = "";

        String product_idString = request.getParameter("product_id");
        String quantityString = request.getParameter("quantity");
        HttpSession session = request.getSession();
        Object user = session.getAttribute("loggedinusername");
        String username = (String) user;
        UserDao userdao = new UserDao("fishmoley");
        User u = userdao.GetUserByUsername(username);
        int id = u.getId();
        int Result;

            try {
                
                int product_id = Integer.parseInt(product_idString);
                
                int quantity = Integer.parseInt(quantityString);
                
                OrderDao orderdao = new OrderDao("fishmoley");
                Result = orderdao.addProductToBasket(product_id, quantity, id);

                if (Result == 1) {


                    session.setAttribute("order_status", "Successfully ordered product!");
                    forwardToJsp = "basket.jsp";
                } else if (Result == 0) {


                    session.setAttribute("order_status", "Failed to order product");
                    forwardToJsp = "allproducts.jsp";
                }
            } catch (NumberFormatException e) {
                forwardToJsp = "error.jsp";
                session.setAttribute("errorMessage", "Not added");

            }

        return forwardToJsp;
    }
}

