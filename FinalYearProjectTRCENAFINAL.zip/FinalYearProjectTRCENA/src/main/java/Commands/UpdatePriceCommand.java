/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Commands;

import Daos.ProductDao;
import Dtos.Product;
import java.util.ArrayList;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author grahamm
 */
public class UpdatePriceCommand implements Command{

    public String execute(HttpServletRequest request, HttpServletResponse response) {
        
        String forwardToJsp = "";
        // Get the information entered into the form by the user
        // Get the parameters from the previous page
        String product_name = request.getParameter("product_name");
        String textAmount = request.getParameter("amount");

        // Confirm information is valid
        if (product_name != null && textAmount != null && !product_name.equals("")) {
            try {
                // Parse number information
                double amount = Double.parseDouble(textAmount);

                // Call on DAO method to update the amount
                ProductDao prodDao = new ProductDao("fishmoley");
                int results = prodDao.productPrice(product_name, amount);

                // Get the session so we can add information to it
                HttpSession session = request.getSession();

                // Add the result number to the session
                session.setAttribute("numUpdated", results);

                // If there were any customers updated, get the list of 
                // updated customers and add to session as well
                if (results > 0) {
                    // Get list of Customers matching the supplied name
                    ArrayList<Product> products = prodDao.getProductsByName(product_name);
                    session.setAttribute("updatedProducts", products);
                }
                // Set the page to be viewed to the results page
                forwardToJsp = "updatePrice.jsp";
            } // Deal with where the user supplied text instead of a number
            catch (NumberFormatException e) {
                // Set the page to be viewed to the error page
                forwardToJsp = "error.jsp";
                // Get the session so we can add information to it
                HttpSession session = request.getSession();
                // Add an error message to the session to be displayed on the error page
                // This lets us inform the user about what went wrong
                session.setAttribute("errorMessage", "Text was supplied for the amount to be updated by.");
            }
        } else {
            // Set the page to be viewed to the error page
            forwardToJsp = "error.jsp";
            // Get the session so we can add information to it
            HttpSession session = request.getSession();

            // Add an error message to the session to be displayed on the error page
            // This lets us inform the user about what went wrong
            session.setAttribute("errorMessage", "A parameter value required for updating was missing");
        }
        return forwardToJsp;
    }

}
