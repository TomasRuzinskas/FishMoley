/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tests;

/**
 *
 * @author Nifemi
 */
public class LoginTest {
    public int add(String s1, String s2){
        int int1 = Integer.parseInt(s1);
        int int2 = Integer.parseInt(s2);
        return int1 + int2;
    }
    
}
