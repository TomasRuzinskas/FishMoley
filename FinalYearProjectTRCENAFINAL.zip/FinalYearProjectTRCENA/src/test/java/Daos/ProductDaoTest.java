/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Colm Erdenetogs
 */
package Daos;

import Dtos.Product;
import java.util.ArrayList;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;


public class ProductDaoTest {
    private static ProductDaoTest productDao;
    public ProductDaoTest()
    {
    }
    
    @BeforeClass
    public static void setUpClass()
    {
        productDao = new ProductDaoTest();
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }
    /**
     * Test of addProduct method, of class ProductDao.
     */
    @Test
    public void testAddProduct() {
        System.out.println("addProduct");
        String product_name = "Nintendo Wii";
        double product_price = 50.00;
        String product_details = "PS6";
        int category_id = 1;
        int supplier_id = 1;     
        ProductDao instance = new ProductDao("fishmoley");
        int expResult = 1;
        int result = instance.addProduct(product_name, product_price, product_details, category_id, supplier_id);
        assertEquals(expResult, result);
    }
    
        /**
     * Test of updateProduct method, of class ProductDao.
     */
    @Test
    public void testUpdateProduct() {
        System.out.println("updateProduct");
        int product_id = 1;
        String product_name = "Xbox Four";
        double product_price = 100.00;
        String product_details = "Console";
        int category_id = 1;
        int supplier_id = 1;     
        ProductDao instance = new ProductDao("fishmoley");
        int expResult = 1;
        int result = instance.updateProducts("Xbox Four", 100.00, "Console", 1, 1, 1);
        assertEquals(expResult, result);
    }
        /**
     * Test of updateProduct method, of class ProductDao.
     */
    @Test
    public void testUpdateProductFailed() {
        System.out.println("updateProductFailed");
        int product_id = 50;
        String product_name = "Xbox Three";
        double product_price = 100.00;
        String product_details = "Console";
        int category_id = 1;
        int supplier_id = 1;     
        ProductDao instance = new ProductDao("fishmoley");
        int expResult = 0;
        int result = instance.updateProducts("Xbox Three", 100.00, "Console", 1, 1, 50);
        assertEquals(expResult, result);
    }
    /**
     * Test of DeleteProduct method, of class ProductDao.
     */
    @Test
    public void testDeleteProduct() {
        System.out.println("deleteProduct");
        int product_id = 43;
        ProductDao instance = new ProductDao("fishmoley");
        int expResult = 1;
        int result = instance.Delete(product_id);
        assertEquals(expResult, result);
    }
    
        /**
     * Test of DeleteProductFailed method, of class ProductDao.
     */
    @Test
    public void testDeleteProductFailed() {
        System.out.println("deleteProduct");
        int product_id = 100;
        ProductDao instance = new ProductDao("fishmoley");
        int expResult = 0;
        int result = instance.Delete(product_id);
        assertEquals(expResult, result);
    }
    
       /**
     * Test of UpdatePrice method, of class ProductDao.
     */
    @Test
    public void testUpdatePrice() {
        System.out.println("updatePrice");
        String product_name = "Xbox Four";
        double product_price = 50.00;
        ProductDao instance = new ProductDao("fishmoley");
        int expResult = 1;
        int result = instance.productPrice(product_name, product_price);
        assertEquals(expResult, result);
    }
    
           /**
     * Test of UpdatePriceFailed method, of class ProductDao.
     */
    @Test
    public void testUpdatePriceFailed() {
        System.out.println("updatePrice");
        String product_name = "Xbox Fail";
        double product_price = 50.00;
        ProductDao instance = new ProductDao("fishmoley");
        int expResult = 0;
        int result = instance.productPrice(product_name, product_price);
        assertEquals(expResult, result);
    }
    
} 
    
