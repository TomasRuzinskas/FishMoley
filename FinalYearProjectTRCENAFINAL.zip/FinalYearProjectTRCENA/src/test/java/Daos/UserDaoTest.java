/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Daos;

import Dtos.User;
import java.util.ArrayList;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Nifemi
 */
public class UserDaoTest {
    
    public UserDaoTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of hashPassword method, of class UserDao.
     */
//    @Test
//    public void testHashPassword() throws Exception {
//        System.out.println("hashPassword");
//        String password = "";
//        UserDao instance = null;
//        String expResult = "";
//        String result = instance.hashPassword(password);
//        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//        //fail("The test case is a prototype.");
//    }

    /**
     * Test of getAllUsers method, of class UserDao.
     */
//    @Test
//    public void testGetAllUsers() {
//        System.out.println("getAllUsers");
//        UserDao instance = new UserDao();
//        ArrayList<User> expResult = null;
//        ArrayList<User> result = instance.getAllUsers();
//        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//        //fail("The test case is a prototype.");
//    }

    /**
     * Test of Login method, of class UserDao.
     */
    @Test
    public void testLogin() {
        System.out.println("Login");
        String username = "tomas";
        String password = "123";
        UserDao instance = new UserDao("Fishmoley");
        String expResult = "f271de0999b83fe5ae1cbd19dbb43e57d4696d58379603a27f44b54e1623c";
        int result = instance.Login(username, password);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    @Test
    public void testLogin1() {
        System.out.println("Login");
        String username = "tomas";
        String password = "123";
        UserDao instance = new UserDao("Fishmoley");
        int expResult = 2;
        int result = instance.Login(username, password);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    @Test
    public void testLogin2() {
        System.out.println("Login");
        String username = "tomas";
        String password = "123";
        UserDao instance = new UserDao("Fishmoley");
        int expResult = 1;
        int result = instance.Login(username, password);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of registerUser method, of class UserDao.
     */
//    @Test
//    public void testRegisterUser() {
//        System.out.println("registerUser");
//        String username = "";
//        String password = "";
//        String password2 = "";
//        String email = "";
//        String phone = "";
//        String address1 = "";
//        String address2 = "";
//        UserDao instance = null;
//        int expResult = 0;
//        int result = instance.registerUser(username, password, password2, email, phone, address1, address2);
//        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }

    /**
     * Test of GetUserByUsername method, of class UserDao.
     */
//    @Test
//    public void testGetUserByUsername() {
//        System.out.println("GetUserByUsername");
//        String username = "";
//        UserDao instance = null;
//        User expResult = null;
//        User result = instance.GetUserByUsername(username);
//        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
    
}
