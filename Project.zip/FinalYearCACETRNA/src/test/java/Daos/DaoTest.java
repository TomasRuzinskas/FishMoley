/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Daos;

import java.sql.Connection;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author d00186050
 */
public class DaoTest {
    
    public DaoTest() {
    }
    /**
     * Test of getConnection method, of class Dao.
     */
    @Test
    public void testGetConnection() {
        System.out.println("getConnection");
        Dao instance = null;
        Connection expResult = null;
        Connection result = instance.getConnection();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of freeConnection method, of class Dao.
     */
    @Test
    public void testFreeConnection() {
        System.out.println("freeConnection");
        Connection con = null;
        Dao instance = null;
        instance.freeConnection(con);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
