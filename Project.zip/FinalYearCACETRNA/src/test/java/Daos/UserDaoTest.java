/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Daos;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author d00186050
 */
public class UserDaoTest {
    
    public UserDaoTest() {
    }
    /**
     * Test of hashPassword method, of class UserDao.
     */
    /**
     * Test of Login method, of class UserDao.
     */
    @Test
    public void testLogin() {
        System.out.println("Login");
        String username = "Tomas";
        String password = "123";
        UserDao userdao = new UserDao("FishMoleyTest");
        int expResult = 2;
        int result = userdao.Login(username, password);
        assertEquals(expResult, result);
    }
        @Test
    public void testLogin2() {
        System.out.println("Login");
        String username = "Colm";
        String password = "456";
        UserDao userdao = new UserDao("FishMoleyTest");
        int expResult = 1;
        int result = userdao.Login(username, password);
        assertEquals(expResult, result);
    }

    /**
     * Test of registerUser method, of class UserDao.
     */
    @Test
    public void testRegisterUser() {
        System.out.println("registerUser");
        String username = "";
        String password = "";
        String password2 = "";
        UserDao instance = null;
        int expResult = 0;
        int result = instance.registerUser(username, password, password2);
        assertEquals(expResult, result);
    }
    
}
