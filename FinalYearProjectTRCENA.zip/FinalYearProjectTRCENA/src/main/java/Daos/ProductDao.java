/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Daos;

import Dtos.Product;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author d00186050
 */
public class ProductDao extends Dao {

    public ProductDao(String databaseName) {
        super(databaseName);
    }

    public ArrayList<Product> AllProducts() {
        ArrayList<Product> products = new ArrayList();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = getConnection();

            String query = "SELECT * FROM products";
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();

            while (rs.next()) {
                Product p = new Product();

                p.setProduct_id(rs.getInt("product_id"));
                p.setProduct_name(rs.getString("product_name"));
                p.setProduct_price(rs.getDouble("product_price"));
                p.setProduct_details(rs.getString("product_details"));
                p.setCategory_id(rs.getInt("category_id"));
                p.setSupplier_id(rs.getInt("supplier_id"));

                products.add(p);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
            } catch (SQLException e) {
                System.out.println("An exception occurred when closing the ResultSet of the getAllProducts(): " + e.getMessage());
            }
            try {
                if (ps != null) {
                    ps.close();
                }
            } catch (SQLException e) {
                System.out.println("An exception occurred when closing the PreparedStatement of the getAllProducts(): " + e.getMessage());
            }
            freeConnection(conn);
        }
        return products;
    }
        public Product SpecificProducts(String id) {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Product p = new Product();
        try {
            conn = getConnection();

            String query = "SELECT * FROM products WHERE product_id=?";
            ps = conn.prepareStatement(query);
            ps.setString(1, id);
            rs = ps.executeQuery();

            if (rs.next()) {
               

                p.setProduct_id(rs.getInt("product_id"));
                p.setProduct_name(rs.getString("product_name"));
                p.setProduct_price(rs.getDouble("product_price"));
                p.setProduct_details(rs.getString("product_details"));
                p.setCategory_id(rs.getInt("category_id"));
                p.setSupplier_id(rs.getInt("supplier_id"));

            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
            } catch (SQLException e) {
                System.out.println("An exception occurred when closing the ResultSet of the SpecificProduct(): " + e.getMessage());
            }
            try {
                if (ps != null) {
                    ps.close();
                }
            } catch (SQLException e) {
                System.out.println("An exception occurred when closing the PreparedStatement of the SpecificProduct(): " + e.getMessage());
            }
            freeConnection(conn);
        }
        return p;
    }
     //   public int addProductToBasket(int id) {
            
     //   }
}
