/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Daos;

import Dtos.Product;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author d00186050
 */
public class ProductDao extends Dao {

    public ProductDao(String databaseName) {
        super(databaseName);
    }

    public ArrayList<Product> AllProducts() {
        ArrayList<Product> products = new ArrayList();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = getConnection();

            String query = "SELECT * FROM products";
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();

            while (rs.next()) {
                Product p = new Product();

                p.setProduct_id(rs.getInt("product_id"));
                p.setProduct_name(rs.getString("product_name"));
                p.setProduct_price(rs.getDouble("product_price"));
                p.setProduct_details(rs.getString("product_details"));
                p.setCategory_id(rs.getInt("category_id"));
                p.setSupplier_id(rs.getInt("supplier_id"));

                products.add(p);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
            } catch (SQLException e) {
                System.out.println("An exception occurred when closing the ResultSet of the getAllProducts(): " + e.getMessage());
            }
            try {
                if (ps != null) {
                    ps.close();
                }
            } catch (SQLException e) {
                System.out.println("An exception occurred when closing the PreparedStatement of the getAllProducts(): " + e.getMessage());
            }
            freeConnection(conn);
        }
        return products;
    }
        public Product SpecificProducts(String id) {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Product p = new Product();
        try {
            conn = getConnection();

            String query = "SELECT * FROM products WHERE product_id=?";
            ps = conn.prepareStatement(query);
            ps.setString(1, id);
            rs = ps.executeQuery();

            if (rs.next()) {
               

                p.setProduct_id(rs.getInt("product_id"));
                p.setProduct_name(rs.getString("product_name"));
                p.setProduct_price(rs.getDouble("product_price"));
                p.setProduct_details(rs.getString("product_details"));
                p.setCategory_id(rs.getInt("category_id"));
                p.setSupplier_id(rs.getInt("supplier_id"));

            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
            } catch (SQLException e) {
                System.out.println("An exception occurred when closing the ResultSet of the SpecificProduct(): " + e.getMessage());
            }
            try {
                if (ps != null) {
                    ps.close();
                }
            } catch (SQLException e) {
                System.out.println("An exception occurred when closing the PreparedStatement of the SpecificProduct(): " + e.getMessage());
            }
            freeConnection(conn);
        }
        return p;
    }
        
        public ArrayList<Product> getProductByName(String name){
            ArrayList<Product> results = new ArrayList();
            Product pd = new Product();
            boolean found = false;
            
            Connection con = getConnection();
            PreparedStatement ps = null;
            ResultSet rs = null;
            
            try{
                con = this.getConnection();
                ps = con.prepareStatement("SELECT * FROM products where product_name = ?");
                ps.setString(1,name);
                rs = ps.executeQuery();
                
                while(rs.next()){
                   pd.setProduct_id(rs.getInt("product_id"));
                   pd.setProduct_name(rs.getString("product_name"));
                   pd.setProduct_price(rs.getDouble("product_price"));
                   pd.setProduct_details(rs.getString("product_details"));
                   
                   results.add(pd);
                   found = true;
                }
            }
              catch (SQLException se) {
             System.out.println("Exception occured in the getProductByName() method: " + se.getMessage());
             se.printStackTrace();
        }
             catch (Exception e){
              System.out.println("Exception occurred: " + e.getMessage());
              e.printStackTrace();
          }
             finally {
              if(rs!=null){
                  try{
                      rs.close();
                  }
                  catch (SQLException ex){
                    System.out.println("Exception occurred when attempting to close ResultSet: " + ex.getMessage());
                }
              }
              if(ps != null){
            
                try{
                    ps.close() ;
                } 
                catch (SQLException ex){
                    System.out.println("Exception occurred when attempting to close the PreparedStatement: " + ex.getMessage());
                }
            }
            freeConnection(con);
        }
            if (!found) {
            return null;
        } else {
            return results;
        }
        }
     //   public int addProductToBasket(int id) {
            
     //   }
}
