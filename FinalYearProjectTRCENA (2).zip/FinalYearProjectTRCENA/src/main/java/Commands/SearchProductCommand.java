/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Commands;

import Daos.ProductDao;
import Dtos.Product;
import java.util.ArrayList;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Nifemi
 */
public class SearchProductCommand implements Command {

    public String execute(HttpServletRequest request, HttpServletResponse response) {

        String forwardToJsp = "";
        // Get the information entered into the form by the user
        // Get the parameters from the previous page
        String productName = request.getParameter("productname");

        // Confirm information is valid
        if (productName != null && !productName.equals("")) {
            try {

                // Call on DAO method to update the amount
                ProductDao pdDao = new ProductDao("fishmoley");
                ArrayList<Product> result = pdDao.getProductByName(productName);

                // Get the session so we can add information to it
                HttpSession session = request.getSession();

                // Add the result number to the session
                session.setAttribute("productSearched", result);

                // If there were any customers updated, get the list of 
                // updated customers and add to session as well
//                if (result != null) {
//                    // Get list of Customers matching the supplied name
//                    ArrayList<Book> books = bkDao.getBookByName(bookName);
//                    session.setAttribute("searchedBook", books);
//                }
                // Set the page to be viewed to the results page
                forwardToJsp = "deals2.jsp";
            } // Deal with where the user supplied text instead of a number
            catch (NumberFormatException e) {
                // Set the page to be viewed to the error page
                forwardToJsp = "error.jsp";
                // Get the session so we can add information to it
                HttpSession session = request.getSession();
                // Add an error message to the session to be displayed on the error page
                // This lets us inform the user about what went wrong
                session.setAttribute("errorMessage", "wrong format.");
            }
        } else {
            // Set the page to be viewed to the error page
            forwardToJsp = "error.jsp";
            // Get the session so we can add information to it
            HttpSession session = request.getSession();

            // Add an error message to the session to be displayed on the error page
            // This lets us inform the user about what went wrong
            session.setAttribute("errorMessage", "A parameter value required for updating was missing");
        }
        return forwardToJsp;
    }

}
